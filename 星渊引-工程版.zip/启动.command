#!/bin/bash
# ============================================
# 星渊引 · 本地运行
# Mac / Linux：双击本文件，或终端里执行 ./启动.command
# ============================================

cd "$(dirname "$0")"

PORT=8000
# 端口被占就往后找
while lsof -i :$PORT >/dev/null 2>&1; do
  PORT=$((PORT+1))
done

URL="http://localhost:$PORT"

echo ""
echo "  星渊引 · 本地服务器"
echo "  ────────────────────────────"
echo "  地址： $URL"
echo "  停止： 在本窗口按 Control + C"
echo ""

# 1 秒后自动开浏览器
( sleep 1; command -v open >/dev/null && open "$URL" || xdg-open "$URL" 2>/dev/null ) &

# 起服务器（Python3 自带，Mac 一般已装）
if command -v python3 >/dev/null 2>&1; then
  python3 -m http.server $PORT
elif command -v python >/dev/null 2>&1; then
  python -m SimpleHTTPServer $PORT
else
  echo "  ✗ 没找到 Python。"
  echo "    Mac 请在终端执行： xcode-select --install"
  echo "    或改用 Node： npx serve"
  read -n 1
fi
