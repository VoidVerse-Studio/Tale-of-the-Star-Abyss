/* ============================================================
 * 星渊引 · 资源管理器 (AssetManager)
 * ------------------------------------------------------------
 * 解决的问题：正片会有几百张立绘 / 几十段视频，不能一次性全加载。
 *
 * 核心机制：
 *   1) 按需加载  load(type, key)        —— 用到才下载
 *   2) 引用计数  retain / release       —— 没人用了才真正释放内存
 *   3) 分组管理  group(id).use([...])   —— 换场景时整组释放
 *   4) 预加载    preload([...])         —— 提前拉下一节，避免卡顿
 *
 * 内存释放说明：
 *   JS 里释放图片 = 断开所有引用 + 清空 src，让 GC 回收解码后的位图。
 *   浏览器仍会把文件留在磁盘 HTTP 缓存里（不占内存），下次秒开。
 * ============================================================ */
(function (global) {
  'use strict';

  const M = () => global.ASSET_MANIFEST;

  /* 把 (type,key) 解析成真实文件路径 */
  function resolve(type, key) {
    const man = M();
    if (!man) throw new Error('manifest 未加载');
    switch (type) {
      case 'sprite': return man.sprites[key];
      case 'eye':    return man.eyes[key] && man.eyes[key].src;
      case 'bg':     return man.bg[key];
      case 'bgm':    return man.bgm[key];
      case 'video':  return man.video && man.video[key];
      default:       return null;
    }
  }

  const AssetManager = {
    _cache: new Map(),      // id -> {el, refs, type, bytes}
    _loading: new Map(),    // id -> Promise (防重复请求)
    _groups: new Map(),     // groupId -> Set(id)
    onProgress: null,       // (loaded,total) => void

    id(type, key) { return type + ':' + key; },

    /* ---------- 加载单个资源 ---------- */
    load(type, key) {
      const id = this.id(type, key);
      const hit = this._cache.get(id);
      if (hit) return Promise.resolve(hit.el);
      if (this._loading.has(id)) return this._loading.get(id);

      const url = resolve(type, key);
      if (!url) return Promise.reject(new Error('资源不存在: ' + id));

      const p = (type === 'bgm' || type === 'video')
        ? this._loadMedia(url, type)
        : this._loadImage(url);

      const wrapped = p.then(el => {
        this._cache.set(id, { el, refs: 0, type });
        this._loading.delete(id);
        return el;
      }).catch(e => {
        this._loading.delete(id);
        throw e;
      });

      this._loading.set(id, wrapped);
      return wrapped;
    },

    _loadImage(url) {
      return new Promise((res, rej) => {
        const img = new Image();
        img.decoding = 'async';
        img.onload = () => res(img);
        img.onerror = () => rej(new Error('图片加载失败: ' + url));
        img.src = url;
      });
    },

    _loadMedia(url, type) {
      return new Promise((res, rej) => {
        const el = document.createElement(type === 'video' ? 'video' : 'audio');
        el.preload = 'auto';
        el.src = url;
        // 音视频不等下载完，能播就算好（避免长时间白屏）
        const ok = () => { cleanup(); res(el); };
        const bad = () => { cleanup(); rej(new Error('媒体加载失败: ' + url)); };
        const cleanup = () => {
          el.removeEventListener('canplaythrough', ok);
          el.removeEventListener('loadeddata', ok);
          el.removeEventListener('error', bad);
        };
        el.addEventListener('canplaythrough', ok, { once: true });
        el.addEventListener('loadeddata', ok, { once: true });
        el.addEventListener('error', bad, { once: true });
        el.load();
      });
    },

    /* ---------- 批量预加载（带进度） ---------- */
    preload(list) {
      if (!list || !list.length) return Promise.resolve([]);
      let done = 0;
      const total = list.length;
      const tick = () => { done++; if (this.onProgress) this.onProgress(done, total); };
      return Promise.all(list.map(it =>
        this.load(it[0], it[1]).then(r => { tick(); return r; })
                               .catch(e => { tick(); console.warn(e.message); return null; })
      ));
    },

    /* ---------- 引用计数 ---------- */
    retain(type, key) {
      const c = this._cache.get(this.id(type, key));
      if (c) c.refs++;
    },
    release(type, key) {
      const id = this.id(type, key);
      const c = this._cache.get(id);
      if (!c) return;
      c.refs--;
      if (c.refs <= 0) this._free(id);
    },
    _free(id) {
      const c = this._cache.get(id);
      if (!c) return;
      const el = c.el;
      try {
        if (el.tagName === 'AUDIO' || el.tagName === 'VIDEO') { el.pause(); el.removeAttribute('src'); el.load(); }
        else el.src = '';                       // 断开位图引用，交给 GC
      } catch (e) {}
      this._cache.delete(id);
    },

    /* ---------- 分组：换场景时整组释放 ---------- */
    group(gid) {
      const self = this;
      return {
        /* 声明这一组要用哪些资源；自动 retain，并释放上一组多余的 */
        use(list) {
          const next = new Set(list.map(it => self.id(it[0], it[1])));
          const prev = self._groups.get(gid) || new Set();
          // 新增的 retain
          next.forEach(id => { if (!prev.has(id)) { const c = self._cache.get(id); if (c) c.refs++; } });
          // 不再需要的 release
          prev.forEach(id => { if (!next.has(id)) { const c = self._cache.get(id); if (c) { c.refs--; if (c.refs <= 0) self._free(id); } } });
          self._groups.set(gid, next);
          return self.preload(list);
        },
        /* 整组释放（离开该场景/章节时调用） */
        dispose() {
          const set = self._groups.get(gid);
          if (!set) return;
          set.forEach(id => { const c = self._cache.get(id); if (c) { c.refs--; if (c.refs <= 0) self._free(id); } });
          self._groups.delete(gid);
        }
      };
    },

    /* ---------- 章节剧本：动态加载（用 script 注入，file:// 也能跑） ---------- */
    loadChapter(id) {
      global.CHAPTERS = global.CHAPTERS || {};
      if (global.CHAPTERS[id]) return Promise.resolve(global.CHAPTERS[id]);
      return new Promise((res, rej) => {
        const sc = document.createElement('script');
        sc.src = 'data/' + id + '.js';
        sc.onload = () => global.CHAPTERS[id]
          ? res(global.CHAPTERS[id])
          : rej(new Error('章节数据为空: ' + id));
        sc.onerror = () => rej(new Error('章节加载失败: ' + id));
        document.head.appendChild(sc);
      });
    },

    /* ---------- 调试：看当前占用 ---------- */
    stats() {
      const byType = {};
      this._cache.forEach(c => { byType[c.type] = (byType[c.type] || 0) + 1; });
      return { cached: this._cache.size, groups: this._groups.size, byType };
    }
  };

  global.Assets = AssetManager;
})(window);
