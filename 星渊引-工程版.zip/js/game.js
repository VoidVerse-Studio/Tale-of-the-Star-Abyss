/* 星渊引 · 游戏逻辑（资源走 Assets 按需加载）*/
const MAN = window.ASSET_MANIFEST;
const POSE_META = MAN.meta;        // 版面参数很小，常驻
const EYES = MAN.eyes;             // 眼部坐标常驻，图片按需
let SCRIPT = [];                   // 由 loadChapter 填充

// 场景背景生成器（程序化水墨）
const SCENE_BG = {
  'default': ['#2A3B32','#1C2A23'],
  '玲珑斋': ['#3a4a38','#1e2a1c'],
  '御剑堂': ['#3d4a40','#20291f'],
  '练剑堂': ['#3d4a40','#20291f'],
  '演武场': ['#4a5340','#252a1c'],
  '制器': ['#4a3a2a','#241a10'],
  '藏经阁': ['#2a2a3a','#16141c'],
  '长廊': ['#3a3428','#1c1810'],
  '淬砂室': ['#3a3428','#1c1810'],
  '回廊': ['#33403a','#181f1a'],
  '小院': ['#2a3b4a','#141c24'],
  '玲珑斋外': ['#2a3b4a','#141c24'],
  '烟霞小楼': ['#4a3d33','#241c16'],
  '静水堂': ['#20302a','#101814'],
  '断崖': ['#3a4450','#1a2028'],
  '石阶': ['#3a4450','#1a2028'],
  '崖亭': ['#40484a','#1e2224'],
  '山道': ['#44503a','#20281a'],
  '山庄外': ['#3a4048','#1a1e24'],
  '边关': ['#5a4a38','#2a2018'],
  '城门': ['#5a4a38','#2a2018'],
  '官道': ['#4a4030','#242018'],
  '茶棚': ['#4a4030','#242018'],
  '客栈': ['#3a3028','#1c1610'],
  '悦来客栈': ['#3a3028','#1c1610'],
  '驿站': ['#3a3028','#1c1610'],
  '驿馆': ['#3a3028','#1c1610'],
  '璃霄城': ['#5a3a44','#2a1820'],
  '灯市': ['#6a4438','#301c18'],
  '灯楼': ['#6a4438','#301c18'],
  '河桥': ['#4a3850','#201828'],
  '小食摊': ['#5a3e30','#281c14'],
  '巷': ['#3a3040','#1a141c'],
  '傩面摊': ['#4a3448','#201420'],
  '御渠': ['#2a3850','#141c28'],
  '归驿': ['#2a2838','#14121c'],
  '琅华宫': ['#5a4020','#2a1c0c'],
  '正殿': ['#5a4020','#2a1c0c'],
  '金殿': ['#5a4020','#2a1c0c'],
  '偏殿': ['#4a3820','#221a0c'],
  '后山': ['#2a3a3a','#141c1c'],
  '崖坳': ['#2a3444','#141820']
};
function bgFor(scene){
  if(!scene) return SCENE_BG['default'];
  for(const k in SCENE_BG){ if(scene.includes(k)) return SCENE_BG[k]; }
  return SCENE_BG['default'];
}
function makeBgSVG(colors, scene){
  const [c1,c2]=colors;
  // 水墨山影 + 竹叶剪影
  return `<svg width="100%" height="100%" viewBox="0 0 480 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="bgg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${c1}"/><stop offset="100%" stop-color="${c2}"/>
      </linearGradient>
      <radialGradient id="glow" cx="50%" cy="30%"><stop offset="0%" stop-color="rgba(196,168,96,.18)"/><stop offset="100%" stop-color="rgba(196,168,96,0)"/></radialGradient>
      <filter id="blur"><feGaussianBlur stdDeviation="3"/></filter>
    </defs>
    <rect width="480" height="900" fill="url(#bgg)"/>
    <rect width="480" height="900" fill="url(#glow)"/>
    <g opacity="0.22" filter="url(#blur)">
      <path d="M0 560 Q120 480 240 540 T480 500 L480 900 L0 900 Z" fill="${c2}"/>
      <path d="M0 660 Q160 600 320 650 T480 620 L480 900 L0 900 Z" fill="${c1}" opacity="0.5"/>
    </g>
    <g opacity="0.16" stroke="${c2}" stroke-width="2.5" fill="none" stroke-linecap="round">
      <path d="M40 0 Q54 200 44 420"/><path d="M44 90 L96 60 M44 90 L4 66 M44 210 L104 190 M44 210 L2 196 M44 330 L92 320"/>
      <path d="M440 0 Q426 240 438 460"/><path d="M438 120 L392 96 M438 120 L476 100 M438 250 L388 236"/>
    </g>
    <g opacity="0.5" fill="rgba(196,168,96,0.5)">
      ${Array.from({length:5},()=>{const x=Math.random()*480,y=Math.random()*400+40;return `<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${(Math.random()*1.5+.5).toFixed(1)}"/>`}).join('')}
    </g>
  </svg>`;
}


// 场景关键词 → 真实背景图
function realBgFor(scene){
  if(!scene) return null;
  const m=[
    [['玲珑斋'],'linglong'],
    [['藏经阁'],'cangjing'],
    [['静水堂'],'jingshui'],
    [['断崖','石阶','断云峡','崖亭','山道','飞云台','绝境'],'duanya'],
    [['山庄外','山庄门','门前','晨雾','浓雾'],'gate'],
    [['玄女','雕像'],'xuannv'],
    [['烟霞小楼'],'yanxia_rain'],
    [['御剑堂','练剑堂','演武场','制器','淬砂'],'yanxia'],
    [['回廊','长廊'],'yanxia2'],
    [['弟子居所','驿馆','客栈'],'yanxia2'],
  ];
  for(const [keys,img] of m){ for(const k of keys){ if(scene.includes(k)) return img; } }
  return null;
}

const $=s=>document.querySelector(s);
const G = {
  i:0, aff:0, typing:false, curText:'', logArr:[], curScene:'',
  els:{},
  init(){
    this.els={bg:$('#bg'),name:$('#nameTag'),text:$('#dialogText'),box:$('#dialogBox'),
      choices:$('#choices'),cg:$('#cgView'),chap:$('#chapterTag'),aff:$('#affVal'),affP:$('#affPanel'),
      marker:$('#markerCard'),hint:$('#nextHint'),cc:$('#chapterCard')};
    // 氛围粒子
    const at=$('#atmos');
    for(let k=0;k<8;k++){const m=document.createElement('div');m.className='mote';
      const s=Math.random()*4+2;m.style.width=s+'px';m.style.height=s+'px';
      m.style.left=Math.random()*100+'%';m.style.animationDuration=(14+Math.random()*12)+'s';
      m.style.animationDelay=(Math.random()*14)+'s';at.appendChild(m);}
    $('#cover').addEventListener('click',()=>this.start());
    $('#hStory').addEventListener('click',()=>this.openStageSel());
    $('#ssClose').addEventListener('click',()=>{ document.getElementById('stageSel').classList.remove('show'); this.openHall(); });
    $('#hSet').addEventListener('click',()=>$('#menu').classList.add('show'));
    this.els.box.addEventListener('click',()=>this.advance());
    this.els.cg.addEventListener('click',()=>{this.els.cg.classList.remove('show');this.next();});
    $('#menuBtn').addEventListener('click',()=>$('#menu').classList.add('show'));
    $('#toHall').addEventListener('click',()=>{ if(confirm('返回章节？本节进度不保存')){ this._stageEnd=null; document.body.classList.remove('playing'); this.showSprite(false); this.openStageSel(); } });
    $('#sndBtn').addEventListener('click',()=>this.toggleSound());
    // 书卷交互
    const bkOpenFn=()=>this.openBook();
    $('#bkCover').addEventListener('click',bkOpenFn);
    $('#bkCover').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();bkOpenFn();}});
    $('#bkPrev').addEventListener('click',e=>{e.stopPropagation();this.turnBook(-1);});
    $('#bkNext').addEventListener('click',e=>{e.stopPropagation();this.turnBook(1);});
    $('#bkClose').addEventListener('click',()=>this.closeBook());
    $('#bkClose').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();this.closeBook();}});
    // 点版面左半 → 後一葉；右半 → 前一葉（竖排右起左行）
    $('#bkSheet').addEventListener('click',e=>{
      if(this._bkSwiped){ this._bkSwiped=false; return; }   // 滑动后不重复翻页
      const r=e.currentTarget.getBoundingClientRect();
      this.turnBook(e.clientX-r.left < r.width/2 ? 1 : -1);
    });
    let bkX=null;
    $('#bkSheet').addEventListener('touchstart',e=>{bkX=e.touches[0].clientX;},{passive:true});
    $('#bkSheet').addEventListener('touchend',e=>{
      if(bkX===null) return;
      const dx=e.changedTouches[0].clientX-bkX; bkX=null;
      if(Math.abs(dx)>44){ this._bkSwiped=true; this.turnBook(dx<0?1:-1); }
    },{passive:true});
    document.addEventListener('keydown',e=>{
      if(!$('#bookView').classList.contains('reading')) return;
      if(e.key==='ArrowLeft') this.turnBook(1);
      else if(e.key==='ArrowRight') this.turnBook(-1);
      else if(e.key==='Escape') this.closeBook();
    });
    window.addEventListener('resize',()=>{if(this.bk) this.layoutBook(); this.layoutSprite(this._curPose);});

    // 加载动态立绘
    this._sprite=document.getElementById('sprite');
    this._curPose='p44';
    Assets.load('sprite','p44').then(img=>{document.getElementById('imgOpen').src=img.src;});
    this.setEye('p44');
    this.loopBlink();
    this.buildFx();
    this.initParallax();
  },
  // ===== 仿 Live2D：眨眼 =====
  setEye(pose){
    // 把容器宽度锁成立绘真实宽高比，眼块的百分比定位才准
    if(POSE_META[pose]){ document.getElementById('portrait').style.aspectRatio=POSE_META[pose].w+'/'+POSE_META[pose].h; this.layoutSprite(pose); }
    const e=EYES[pose], el=document.getElementById('imgBlink');
    if(!e){ el.style.display='none'; return; }
    el.style.display='';
    el.style.left=e.x+'%'; el.style.top=e.y+'%'; el.style.width=e.w+'%';
    Assets.load('eye',pose).then(img=>{ if(this._curPose===pose) el.src=img.src; });
  },
  blink(){
    const el=document.getElementById('imgBlink');
    if(!el||!EYES[this._curPose]||this._posing) return;
    el.classList.add('shut');
    setTimeout(()=>el.classList.remove('shut'),190);
  },
  loopBlink(){
    clearTimeout(this._blinkT);
    const wait=2400+Math.random()*2600;      // 2.4～5.0 秒眨一次
    this._blinkT=setTimeout(()=>{
      if(this._sprite&&this._sprite.classList.contains('on')){
        this.blink();
      }
      this.loopBlink();
    },wait);
  },

  spriteFor(scene){
    var s=scene||'';
    if(s.includes('小院')) return 'p61';                      // 八 · 月下试剑
    if(s.includes('御剑')) return 'p47';                      // 二 · 三师兄昀
    if(s.includes('演武')) return 'p44';                      // 三 · 演武场对练
    if(s.includes('长廊')||s.includes('淬砂')) return 'p47';   // 六 · 受罚之夜
    if(s.includes('回廊')) return 'p44';                      // 七 · 雨中同伞
    if(s.includes('小楼')||s.includes('烟霞')) return 'p88';   // 九 · 楚图与鸦
    return 'p44';
  },
  // 按姿势的实际比例定尺寸：宽不溢出、底边压进对话框、眼睛落在同一高度
  layoutSprite(pose){
    const m=POSE_META[pose], sp=this._sprite, app=document.getElementById('app');
    if(!m||!sp||!app) return;
    const AW=app.clientWidth, AH=app.clientHeight;
    if(!AW||!AH) return;
    let H=AH*0.90, W=H*m.ar;
    const maxW=AW*1.06;                       // 允许略微出血，避免半身像被缩得太小
    if(W>maxW){ W=maxW; H=W/m.ar; }
    let top=AH*0.215-m.eyeY*H;                // 眼睛对齐到画面 21.5% 高
    const floor=AH*0.84;                      // 底边必须没入对话框，才不会露出裁切硬边
    if(top+H<floor) top=floor-H;
    sp.style.height=H+'px';
    sp.style.top=top+'px';
  },
  _randPose(pool){
    var avail=(pool||[]).filter(p=>MAN.sprites[p]);
    return avail.length?avail[Math.floor(Math.random()*avail.length)]:'p44';
  },
  poseByText(text){ return null; },
  setSpritePose(scene){
    const pose=this.spriteFor(scene);
    if(pose===this._curPose||!MAN.sprites[pose]) return;
    const cur=document.getElementById('imgOpen'), fade=document.getElementById('imgFade');
    this._posing=true;
    document.getElementById('imgBlink').classList.remove('shut');
    if(cur.src){ fade.src=cur.src; fade.classList.add('on'); }
    this._curPose=pose;
    this.setEye(pose);
    Assets.load('sprite',pose).then(img=>{
      if(this._curPose!==pose) return;          // 期间又换了，丢弃
      cur.src=img.src;
      requestAnimationFrame(()=>{ fade.classList.remove('on'); });
    }).catch(()=>{ fade.classList.remove('on'); });
    clearTimeout(this._poseT);
    this._poseT=setTimeout(()=>{ this._posing=false; },560);
  },
  initParallax(){
    if(this._pxReady) return; this._pxReady=true;
    this.px=0; this.py=0; this._pxT=0;
    const app=document.getElementById('app');
    const set=(x,y)=>{                        // x,y ∈ [-1,1]
      this._pxTx=Math.max(-1,Math.min(1,x));
      this._pxTy=Math.max(-1,Math.min(1,y));
      this._pxRun();
    };
    // 桌面：鼠标位置
    app.addEventListener('pointermove',e=>{
      if(e.pointerType==='touch') return;     // 触摸另走陀螺仪/拖动
      const r=app.getBoundingClientRect();
      set((e.clientX-r.left)/r.width*2-1, (e.clientY-r.top)/r.height*2-1);
    });
    app.addEventListener('pointerleave',()=>set(0,0));
    // 触摸：手指拖动时轻微跟随
    app.addEventListener('touchmove',e=>{
      const t=e.touches[0]; if(!t) return;
      const r=app.getBoundingClientRect();
      set((t.clientX-r.left)/r.width*2-1, (t.clientY-r.top)/r.height*2-1);
    },{passive:true});
    app.addEventListener('touchend',()=>{ clearTimeout(this._pxHold); this._pxHold=setTimeout(()=>set(0,0),900); },{passive:true});
    // 手机陀螺仪（有则用，作为常态漂移）
    if(window.DeviceOrientationEvent){
      window.addEventListener('deviceorientation',e=>{
        if(e.gamma==null) return;
        set(Math.max(-1,Math.min(1,e.gamma/28)), Math.max(-1,Math.min(1,((e.beta||0)-45)/34)));
      });
    }
  },
  _pxRun(){                                    // 缓动逼近目标，避免生硬
    if(this._pxRAF) return;
    const step=()=>{
      const tx=this._pxTx||0, ty=this._pxTy||0;
      this.px+=(tx-this.px)*0.09; this.py+=(ty-this.py)*0.09;
      document.getElementById('app').style.setProperty('--px',this.px.toFixed(4));
      document.getElementById('app').style.setProperty('--py',this.py.toFixed(4));
      if(Math.abs(tx-this.px)>0.002||Math.abs(ty-this.py)>0.002){ this._pxRAF=requestAnimationFrame(step); }
      else{ this._pxRAF=0; }
    };
    this._pxRAF=requestAnimationFrame(step);
  },
  buildFx(){
    const fx=document.getElementById('fx'); if(!fx||fx._built) return; fx._built=true;
    const glow=document.createElement('div'); glow.className='glow'; fx.appendChild(glow);
    const N=14;
    for(let i=0;i<N;i++){
      const m=document.createElement('div'); m.className='mote';
      const sz=2+Math.random()*4;
      m.style.width=sz+'px'; m.style.height=sz+'px';
      m.style.left=(Math.random()*100)+'%';
      m.style.animationDuration=(15+Math.random()*16)+'s';
      m.style.animationDelay=(-Math.random()*24)+'s';
      fx.appendChild(m);
    }
  },
  // ===== 背景音乐 =====
  initAudio(){
    if(this._audioReady) return;
    this._audioReady=true;
    this.muted=false; this._track=null;
    const a=new Audio();a.loop=true;a.preload='auto';a.volume=0;
    this.bgm={yun:a};
    Assets.load('bgm','yun').then(src=>{ a.src=src.src; a.load(); if(this._pendingPlay) this.playBgm(); });
    this._fadeT={};
  },
  fadeTo(a,vol,ms){
    if(!a) return;
    clearInterval(this._fadeT[a.src]);
    const from=a.volume, steps=Math.max(1,Math.round(ms/40)); let k=0;
    if(vol>0 && a.paused){ a.play().catch(()=>{}); }
    this._fadeT[a.src]=setInterval(()=>{
      k++; a.volume=Math.min(1,Math.max(0,from+(vol-from)*k/steps));
      if(k>=steps){ clearInterval(this._fadeT[a.src]); if(vol===0) a.pause(); }
    },40);
  },
  // 全程只放昀的主题
  playBgm(){
    this.initAudio();
    if(this._track==='yun') return;
    this._track='yun';
    if(this.muted) return;
    this.fadeTo(this.bgm.yun,0.55,1200);
  },
  toggleSound(){
    this.initAudio();
    this.muted=!this.muted;
    document.getElementById('sndBtn').classList.toggle('off',this.muted);
    if(this.muted){ this.fadeTo(this.bgm.yun,0,300); }
    else { this._track=null; this.playBgm(); }
  },
  showSprite(on,dim){ if(!this._sprite)return;
    if(on){
      this.setSpritePose(this.curScene);
      this._sprite.classList.add('on'); this._sprite.classList.toggle('dim',!!dim);
    }
    else{ this._sprite.classList.remove('on'); }
  },
  start(){ this.initAudio(); this.playBgm(); $('#cover').classList.add('off'); setTimeout(()=>{ this.openHall(); },600); },

  openHall(){
    this.buildStages(); this.loadProgress();
    document.body.classList.remove('playing');
    document.getElementById('hall').classList.add('show');
    document.getElementById('stageSel').classList.remove('show');
    this.showSprite(false);
    const th=document.getElementById('toHall'); if(th) th.style.display='none';
  },
  openStageSel(focusK){
    const stages=this.buildStages(); this.loadProgress();
    const path=document.getElementById('ssList'); path.innerHTML='';
    const N=stages.length;
    const stepY=118, padTop=26;
    // 左右错落的横向位置（百分比），蜿蜒感
    const xs=[30,52,68,58,38,26,42,62,50];
    path.style.height=(padTop+N*stepY+40)+'px';
    // 先画连线（SVG）
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.setAttribute('style','position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0');
    let d='';
    const pts=stages.map((st,k)=>({x:(xs[k%xs.length]),y:padTop+k*stepY+26}));
    pts.forEach((p,k)=>{
      if(k===0) d+='M '+p.x+'% '+p.y+' ';
      else{ const pr=pts[k-1]; const my=(pr.y+p.y)/2;
        d+='C '+pr.x+'% '+my+', '+p.x+'% '+my+', '+p.x+'% '+p.y+' '; }
    });
    const pathEl=document.createElementNS('http://www.w3.org/2000/svg','path');
    pathEl.setAttribute('d',d);
    pathEl.setAttribute('fill','none');
    pathEl.setAttribute('stroke','rgba(214,180,120,.4)');
    pathEl.setAttribute('stroke-width','2.5');
    pathEl.setAttribute('stroke-dasharray','2 8');
    pathEl.setAttribute('stroke-linecap','round');
    svg.appendChild(pathEl); path.appendChild(svg);
    // 再放节点
    stages.forEach((st,k)=>{
      const n=k+1;
      const done=n<=this.doneCount, cur=(n===this.doneCount+1), unlocked=done||cur;
      const isBattle=false;  // 以后战斗节点在此判定
      const el=document.createElement('div');
      el.className='chNode'+(done?' done':'')+(cur?' cur':'')+(unlocked?'':' locked');
      const left=xs[k%xs.length];
      el.style.left=left+'%'; el.style.top=(padTop+k*stepY)+'px';
      el.style.transform='translateX(-26px)';
      const num=String(k).padStart(2,'0');
      const kind=isBattle?'battle':'story';
      const icon=isBattle?'⚔':'❖';
      el.innerHTML='<div class="icon"><span class="no">'+num+'</span><span class="kind">'+kind+'</span>'+icon+'</div>'+
                   '<div class="label">'+st.title+'</div>';
      if(unlocked) el.addEventListener('click',()=>this.enterStage(k));
      path.appendChild(el);
    });
    document.getElementById('stageSel').classList.add('show');
    // 滚到当前可玩节点
    const cn=this.doneCount; // 索引
    setTimeout(()=>{
      const sc=document.getElementById('chScroll');
      const target=Math.max(0,(padTop+cn*stepY)-sc.clientHeight*0.4);
      sc.scrollTo({top:target,behavior:(focusK!=null?'smooth':'auto')});
    },60);
  },
  /* 扫描某一节用到的资源，供预加载 */
  scanStageAssets(k){
    const st=this._stages[k]; if(!st) return [];
    const need=new Set(), out=[];
    for(let i=st.i;i<=st.end;i++){
      const n=SCRIPT[i]; if(!n) continue;
      if(n.t==='scene'){
        const b=realBgFor(n.v); if(b&&MAN.bg[b]) need.add('bg|'+b);
        const p=this.spriteFor(n.v);
        if(MAN.sprites[p]){ need.add('sprite|'+p); if(MAN.eyes[p]) need.add('eye|'+p); }
      }
    }
    need.forEach(s=>{ const a=s.split('|'); out.push([a[0],a[1]]); });
    return out;
  },
  enterStage(k){
    const st=this._stages[k];
    this._curStage=k; this._stageEnd=st.end;
    // 本节资源成组加载；上一节不再用的会被自动释放
    Assets.group('stage').use(this.scanStageAssets(k));
    // 顺手预拉下一节，切换时不卡
    if(this._stages[k+1]) setTimeout(()=>Assets.preload(this.scanStageAssets(k+1)),1200);
    document.getElementById('stageSel').classList.remove('show');
    document.getElementById('hall').classList.remove('show');
    document.body.classList.add('playing');
    const th=document.getElementById('toHall'); if(th) th.style.display='flex';
    this.i=st.i; this.aff=0;
    this.run();
  },
  finishStage(){
    // 本节读完：解锁下一节、存档，回到【章节路径】而非大厅
    const done=this._curStage+1;
    if(done>this.doneCount){ this.doneCount=done; this.saveProgress(); }
    this._stageEnd=null;
    this._track=null; if(this.bgm){ this.fadeTo(this.bgm.yun,0,900); }
    document.body.classList.remove('playing'); this.showSprite(false);
    document.getElementById('hall').classList.remove('show');
    const th=document.getElementById('toHall'); if(th) th.style.display='none';
    this.openStageSel(this._curStage+1);
  },
  resume(){ $('#menu').classList.remove('show'); },
  restart(){ $('#menu').classList.remove('show'); this.openHall(); return; },
  _oldstart(){ $('#menu').classList.remove('show'); this.i=0;this.aff=0;this.aff=0;this.logArr=[];this.updateAff();this.run(); },
  save(){ try{localStorage.setItem('xyy_save',JSON.stringify({i:this.i,aff:this.aff}));alert('进度已保存');}catch(e){alert('保存失败');} $('#menu').classList.remove('show'); },
  load(){ try{const s=JSON.parse(localStorage.getItem('xyy_save'));if(s){this.i=s.i;this.aff=s.aff;this.updateAff();$('#menu').classList.remove('show');this.run();}else alert('无存档');}catch(e){alert('读取失败');} },
  showLog(){ const l=$('#logList');l.innerHTML=this.logArr.slice(-60).map(e=>`<div class="li ${e.nm?'':'nar'}">${e.nm?`<div class="nm">${e.nm}</div>`:''}<div class="tx">${e.tx}</div></div>`).join('');$('#log').classList.add('show');$('#menu').classList.remove('show');setTimeout(()=>l.scrollTop=l.scrollHeight,50); },
  hideLog(){ $('#log').classList.remove('show'); },

  setScene(scene){
    if(scene===this.curScene)return; this.curScene=scene;
    this.showSprite(false);
    const realBg=realBgFor(scene);
    const layer=document.createElement('div');layer.className='layer';
    if(realBg && MAN.bg[realBg]){
      layer.style.backgroundImage='url('+MAN.bg[realBg]+')';   // 浏览器自行按需拉取+缓存
      Assets.load('bg',realBg).catch(()=>{});                  // 登记进缓存以便统一释放
      layer.style.backgroundSize='cover';
      layer.style.backgroundPosition='center';
    } else {
      layer.innerHTML=makeBgSVG(bgFor(scene),scene);
    }
    this.els.bg.appendChild(layer);
    requestAnimationFrame(()=>{requestAnimationFrame(()=>layer.classList.add('on'))});
    // 清理旧层
    const layers=this.els.bg.querySelectorAll('.layer');
    if(layers.length>2){setTimeout(()=>layers[0].remove(),1300);}
  },

  run(){ this.node(); },

  // ===== 章节/小节 索引 =====
  buildStages(){
    if(this._stages) return this._stages;
    if(!SCRIPT.length) return [];
    const arr=[]; let chap='';
    for(let i=0;i<SCRIPT.length;i++){
      if(SCRIPT[i].t==='chapter' && SCRIPT[i].v.indexOf('终')<0) chap=SCRIPT[i].v;
      if(SCRIPT[i].t==='section') arr.push({i, title:SCRIPT[i].v, chap});
    }
    // 每节的结束点 = 下一节起点-1，最后一节到末尾
    arr.forEach((st,k)=>{ st.end = (k+1<arr.length)? arr[k+1].i-1 : SCRIPT.length-1; });
    this._stages=arr; return arr;
  },
  loadProgress(){
    let done=0;
    try{ const v=localStorage.getItem('xyy_progress'); if(v!=null) done=parseInt(v)||0; }catch(e){}
    this.unlocked=Math.max(1,done+ (done?0:1));   // 至少解锁第1节
    this.doneCount=done;
  },
  saveProgress(){
    try{ localStorage.setItem('xyy_progress',String(this.doneCount)); }catch(e){}
  },

  node(){
    if(this._stageEnd!=null && this.i>this._stageEnd){ this.finishStage(); return; }
    if(this.i>=SCRIPT.length){ this.end(); return; }
    const n=SCRIPT[this.i];
    switch(n.t){
      case 'chapter': this.showChapter(n.v); return;
      case 'section': this.i++; this.node(); return; // 小节标题跳过(可选显示)
      case 'scene': this.setScene(n.v); this.i++; this.node(); return;
      case 'marker': this.showMarker(n.v); return;
      case 'cg': this.showCG(n.v); return;
      case 'choices': this.showChoices(n.v); return;
      case 'book': this.showBook(n.v); return;
      case 'dialogue': this.showDialogue(n.v.name, n.v.text); return;
      case 'narration': this.showNarration(n.v); return;
      case 'action': this.showNarration('（'+n.v+'）', true); return;
      default: this.i++; this.node();
    }
  },

  advance(){
    if(this.typing){ this.finishTyping(); return; }
    this.next();
  },
  next(){ this.i++; this.node(); },

  // ===== 书卷 · 翻阅 =====
  cnNum(n){
    const d='零一二三四五六七八九';
    if(n<10) return d[n];
    if(n===10) return '十';
    if(n<20) return '十'+(n%10?d[n%10]:'');
    if(n<100) return d[Math.floor(n/10)]+'十'+(n%10?d[n%10]:'');
    return String(n);
  },
  showBook(b){
    this.bk={paras:b.paras,title:b.title,p:0,n:1,w:0};
    $('#bkTitleSlip span').textContent=b.title;
    $('#bkSeal span').textContent=b.seal||'';
    $('#bkShutSub').textContent=b.sub||'';
    $('#bkSpine .rt').textContent=b.title;
    // 卷首题 + 正文
    $('#bkFlow').innerHTML='<p class=\'t\'>'+b.title+'</p>'+b.paras.map(t=>
      t.charAt(0)==='#' ? '<p class=\'h\'>'+t.slice(1)+'</p>' : '<p>'+t+'</p>'
    ).join('');
    $('#bkFlow').style.transform='translateX(0)';
    const v=$('#bookView');
    v.classList.remove('reading','jiuzhou','notitle');
    if(b.theme) v.classList.add(b.theme);
    if(b.notitle) v.classList.add('notitle');
    v.classList.add('show');
    this.els.box.style.visibility='hidden';
  },
  openBook(){
    if(!this.bk) return;
    $('#bookView').classList.add('reading');
    requestAnimationFrame(()=>requestAnimationFrame(()=>this.layoutBook()));
    setTimeout(()=>this.layoutBook(),260);   // 字体载入后再量一次
  },
  layoutBook(){
    const b=this.bk; if(!b) return;
    const page=$('#bkPage'), clip=$('#bkClip'), flow=$('#bkFlow');
    const LH=30, cw=page.clientWidth;
    if(cw<LH) return;
    const cols=Math.max(1,Math.floor(cw/LH));
    b.w=cols*LH;
    clip.style.width=b.w+'px';                      // 收成整栏数，界行才对得齐
    clip.style.right=Math.floor((cw-b.w)/2)+'px';
    const total=Math.max(flow.offsetWidth,flow.scrollWidth,b.w);
    b.n=Math.max(1,Math.ceil((total-1)/b.w));
    if(b.p>b.n-1) b.p=b.n-1;
    this.renderBook();
  },
  renderBook(){
    const b=this.bk; if(!b) return;
    $('#bkFlow').style.transform='translateX('+(b.p*b.w)+'px)';
    $('#bkNum').textContent='第 '+this.cnNum(b.p+1)+' 葉 · 共 '+this.cnNum(b.n)+' 葉';
    $('#bkSpine .lf').textContent=this.cnNum(b.p+1);
    $('#bkPrev').disabled=(b.p===0);
    $('#bkNext').disabled=(b.p>=b.n-1);
  },
  turnBook(d){
    const b=this.bk; if(!b||!b.w) return;
    const np=b.p+d;
    if(np<0||np>b.n-1) return;
    b.p=np; this.renderBook();
    const sh=$('#bkSheet');
    sh.classList.remove('turning'); void sh.offsetWidth; sh.classList.add('turning');
  },
  closeBook(){
    $('#bookView').classList.remove('show','reading');
    this.els.box.style.visibility='';
    this.bk=null;
    this.next();
  },
  showChapter(title){
    const parts=title.split('·');
    $('#ccNum').textContent=parts[0].trim();
    $('#ccTtl').textContent=parts[1]?parts[1].trim():'';
    this.els.chap.textContent=parts[0].trim();
    const cc=this.els.cc; cc.classList.add('show');
    cc.querySelector('.num').style.animation='none';cc.querySelector('.ttl').style.animation='none';cc.querySelector('.line').style.animation='none';
    requestAnimationFrame(()=>{cc.querySelector('.num').style.animation='';cc.querySelector('.ttl').style.animation='';cc.querySelector('.line').style.animation='';});
    setTimeout(()=>{
      if(this.i>=SCRIPT.length-1){
        // 分节模式：末章卡显示后回章节页并解锁
        if(this._stageEnd!=null){
          setTimeout(()=>{ cc.classList.remove('show'); this.finishStage(); }, 1600);
          return;
        }
        this.end(true); return;   // 非分节：留着终章卡
      }
      cc.classList.remove('show');this.next();
    },2600);
  },
  showMarker(txt){
    const m=this.els.marker;m.textContent='· '+txt+' ·';m.classList.add('show');
    setTimeout(()=>{m.classList.remove('show');setTimeout(()=>this.next(),500);},1600);
  },
  showCG(label){
    const parts=label.split('·');
    $('#cgBg').innerHTML=makeBgSVG(bgFor(this.curScene),this.curScene);
    $('#cgLabel').innerHTML=`<div class="cgz">${parts[0].trim()}</div>${parts[1]?`<div class="cgsub">${parts.slice(1).join('·').trim()}</div>`:''}`;
    this.els.cg.classList.add('show');
  },
  showChoices(group){
    const c=this.els.choices;c.innerHTML='';c.classList.add('show');
    group.forEach((opt)=>{
      const b=document.createElement('div');b.className='choice';b.textContent=opt.opt;
      b.addEventListener('click',()=>{
        c.classList.remove('show');
        if(opt.aff){this.aff+=opt.aff;this.updateAff();this.flashAff(opt.aff);}
        // 播放该选项的回复
        this.replyQueue=opt.replies.slice();
        this.playReply();
      });
      c.appendChild(b);
    });
  },
  playReply(){
    if(this.replyQueue&&this.replyQueue.length){
      const r=this.replyQueue.shift();
      if(r.type==='dialogue') this.showDialogue(r.val.name,r.val.text,true);
      else this.showNarration(r.val,false,true);
    }else{ this.next(); }
  },
  _replyMode:false,
  showDialogue(name,text,isReply){
    this._replyMode=!!isReply;
    this.els.name.textContent=name;this.els.name.classList.remove('hide');
    this.els.text.className='';
    this.logArr.push({nm:name,tx:text.replace(/（[^）]*）/g,'')});
    this.type(text);
    if(name==='昀'||name==='南宫昀'){ this.els.affP.classList.add('show'); this.showSprite(true,false); }
    else if(name==='我'){ this.showSprite(this._sprite&&this._sprite.classList.contains('on'),true); }
    else{ this.showSprite(this._sprite&&this._sprite.classList.contains('on'),true); }
  },
  showNarration(text,isAction,isReply){
    this._replyMode=!!isReply;
    this.els.name.classList.add('hide');this.els.name.textContent='';
    this.els.text.className='narr';
    this.logArr.push({nm:'',tx:text});
    this.type(text);
  },

  type(text){
    this.typing=true;this.curText=text;this.els.hint.style.display='none';
    const el=this.els.text;el.innerHTML='';let idx=0;
    // 去掉台词里的（动作）单独成灰，简单处理：整体打字
    const speed=28;
    clearInterval(this._tt);
    this._tt=setInterval(()=>{
      if(idx<text.length){ el.innerHTML=this.fmt(text.slice(0,idx+1))+'<span class="cursor">▌</span>';idx++; }
      else{ this.finishTyping(); }
    },speed);
  },
  fmt(t){ return t.replace(/（([^）]*)）/g,'<span style="color:#6a7a68;font-size:.9em">（$1）</span>'); },
  finishTyping(){
    clearInterval(this._tt);this.typing=false;
    this.els.text.innerHTML=this.fmt(this.curText);
    this.els.hint.style.display='block';
    // 若在回复队列中，点击继续播放回复
  },
  advance(){
    if(this.typing){this.finishTyping();return;}
    if(this._replyMode&&this.replyQueue&&this.replyQueue.length){this.playReply();return;}
    if(this._replyMode&&this.replyQueue&&this.replyQueue.length===0){this._replyMode=false;this.next();return;}
    this.next();
  },

  updateAff(){ this.els.aff.textContent=this.aff; },
  flashAff(v){
    const f=document.createElement('div');f.textContent='好感 +'+v;
    f.style.cssText='position:absolute;top:90px;right:20px;z-index:45;color:#C4A860;font-size:14px;font-weight:600;text-shadow:0 2px 8px #000;animation:floatUp 1.5s ease forwards;pointer-events:none';
    $('#app').appendChild(f);setTimeout(()=>f.remove(),1500);
  },
  end(keepCard){
    document.body.classList.remove('playing');this.els.affP.classList.remove('show');
    this._track=null; if(this.bgm){ this.fadeTo(this.bgm.yun,0,1500); }
    this.showSprite(false);
    if(keepCard) return;                    // 章节卡已经在画面上了
    const cc=this.els.cc;$('#ccNum').textContent='第一章';$('#ccTtl').textContent='终';
    cc.classList.add('show');
  }
};
// floatUp keyframe
const st=document.createElement('style');st.textContent='@keyframes floatUp{0%{opacity:0;transform:translateY(10px)}20%{opacity:1}100%{opacity:0;transform:translateY(-30px)}}';document.head.appendChild(st);
window.G=G;
/* 启动：先拉第一章剧本，再初始化 */
Assets.loadChapter('chapter01').then(ch=>{
  SCRIPT = ch.script;
  G.init();
  var b=document.getElementById('boot');
  if(b){ b.classList.add('off'); setTimeout(function(){ b.remove(); },600); }
}).catch(e=>{
  document.getElementById('cover').innerHTML =
    '<div style="color:#c4a860;text-align:center;padding:40px;line-height:2">'+
    '剧本加载失败<br><span style="font-size:12px;opacity:.7">'+e.message+
    '<br>若是本地双击打开，请改用本地服务器或部署后访问</span></div>';
});
