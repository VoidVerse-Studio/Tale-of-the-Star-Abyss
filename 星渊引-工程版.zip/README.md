# 星渊引 · 工程结构说明

```
星渊引/
├── index.html           外壳（结构 + 样式），不含任何素材
├── js/
│   ├── loader.js        资源管理器：按需加载 / 引用计数 / 分组释放
│   └── game.js          游戏逻辑
├── data/
│   ├── manifest.js      资源清单（新增素材只改这里）
│   └── chapter01.js     第一章剧本（按需加载）
└── assets/
    ├── sprites/         立绘 + 眼部贴片
    ├── bg/              背景
    ├── bgm/             音乐
    └── video/           CG 视频（留给即梦生成的动画）
```

## 为什么这么改

重构前：所有图片音频用 base64 塞进一个 5MB 的 HTML，**打开就要下完整个文件**。
内容涨到 100 倍就是 500MB 一个文件，手机直接打不开。

重构后：

| | 重构前 | 重构后 |
|---|---|---|
| 打开时下载 | 5.02 MB | **104 KB** |
| 素材 | 全部内嵌 | 用到才拉，用完释放 |
| 加内容 | 文件线性变大 | 首屏体积**不变** |

关键在于**首屏体积和内容总量脱钩了**。以后加 500 张立绘，打开速度还是一样快。

---

## 怎么加内容

### 加一张立绘

1. 图片丢进 `assets/sprites/`，比如 `p90.webp`
2. 闭眼版切出眼部贴片 `p90_eye.webp`（只要眼睛那一小块）
3. 在 `data/manifest.js` 里补三处：

```js
sprites: { "p90": "assets/sprites/p90.webp" },
eyes:    { "p90": { "src":"assets/sprites/p90_eye.webp", "x":39, "y":15, "w":24 } },
meta:    { "p90": { "ar":0.73, "w":1104, "h":1500, "eyeY":0.20 } }
```

- `x/y/w` 是眼部贴片在立绘上的位置（百分比）
- `ar` 宽高比，`eyeY` 眼睛在立绘上的高度比例（用来对齐不同景别）

代码不用动。

### 加一章剧情

复制 `data/chapter01.js` → `chapter02.js`，改里面的 id 和内容。
加载方式：`Assets.loadChapter('chapter02')`。

### 加 CG 视频（即梦生成的动画）

1. 视频放 `assets/video/`
2. `manifest.js` 里补 `video: { "cg_雨伞": "assets/video/cg_雨伞.mp4" }`
3. 剧本里用 `{"t":"video","v":"cg_雨伞"}`（这个节点类型还需在 game.js 的 `node()` 里加一个 case）

视频**不要预加载**，让它边播边缓冲，否则很占内存。

---

## 资源管理器怎么用

```js
// 单个加载（自动缓存，重复调用不会重复下载）
await Assets.load('sprite', 'p44');

// 成组加载：进入某一节时声明这节要什么
// 上一组里不再需要的会自动释放，内存不会累积
await Assets.group('stage').use([
  ['sprite','p44'], ['eye','p44'], ['bg','linglong']
]);

// 离开章节，整组释放
Assets.group('stage').dispose();

// 预加载（不阻塞，用来提前拉下一节）
Assets.preload([['sprite','p47']]);

// 看当前内存里缓存了多少
console.log(Assets.stats());
```

**引用计数**：同一个资源被多处使用时，只有全部释放后才真正回收，不会误删。

---

## 部署与后续

### 现在就能做

- 整个文件夹丢到任何静态托管（Netlify / Vercel / GitHub Pages / 对象存储）
- 本地测试需要起服务器（不能直接双击 index.html，浏览器会拦跨域请求）：
  ```
  python3 -m http.server 8000
  ```
  然后访问 `http://localhost:8000`

### 接 CDN（用户量上来时）

把 `assets/` 整个传到 CDN，然后在 `manifest.js` 里把路径改成 CDN 地址即可：

```js
sprites: { "p44": "https://你的CDN域名/sprites/p44.webp" }
```

代码一行都不用改——这就是把路径集中到清单里的好处。

### 接后端（抽卡 / 云存档）

目前进度存在 `localStorage`（本地）。要改成云端时，只需替换 `game.js` 里这两个方法：

```js
loadProgress()   // 改成：从服务器拉
saveProgress()   // 改成：向服务器提交
```

其余代码不受影响。

### 打包成 App

用 Capacitor 把这个文件夹包成 iOS / Android 安装包：

```
npm install @capacitor/cli @capacitor/core
npx cap init
npx cap add ios
npx cap add android
```

把本目录作为 `webDir`，然后用 Xcode / Android Studio 编译。
