@echo off
chcp 65001 >nul
cd /d "%~dp0"

set PORT=8000

echo.
echo   星渊引 · 本地服务器
echo   ----------------------------
echo   地址： http://localhost:%PORT%
echo   停止： 在本窗口按 Ctrl + C
echo.

start "" http://localhost:%PORT%

python -m http.server %PORT% 2>nul
if errorlevel 1 (
  py -m http.server %PORT% 2>nul
)
if errorlevel 1 (
  echo.
  echo   x 没找到 Python
  echo     请到 python.org 下载安装，安装时勾选 "Add to PATH"
  echo     或改用 Node:  npx serve
  echo.
  pause
)
