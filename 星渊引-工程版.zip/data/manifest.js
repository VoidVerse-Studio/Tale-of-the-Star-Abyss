/* 资源清单 —— 新增素材只改这里，不用动代码
 * 立绘: sprites[key] = 路径 ; 对应的闭眼贴片 eyes[key]
 * 背景: bg[key]      音乐: bgm[key]      视频: video[key]
 * meta 是立绘的版面参数(宽高比/眼睛高度)，加新立绘时一并补
 */
window.ASSET_MANIFEST = {
 "sprites": {
  "p44": "assets/sprites/p44.webp",
  "p47": "assets/sprites/p47.webp",
  "p54": "assets/sprites/p54.webp",
  "p61": "assets/sprites/p61.webp",
  "p88": "assets/sprites/p88.webp"
 },
 "eyes": {
  "p44": {
   "src": "assets/sprites/p44_eye.webp",
   "x": 31.266,
   "y": 7.986,
   "w": 22.691
  },
  "p47": {
   "src": "assets/sprites/p47_eye.webp",
   "x": 44.553,
   "y": 8.707,
   "w": 26.035
  },
  "p54": {
   "src": "assets/sprites/p54_eye.webp",
   "x": 36.376,
   "y": 4.934,
   "w": 21.526
  },
  "p61": {
   "src": "assets/sprites/p61_eye.webp",
   "x": 46.78,
   "y": 10.881,
   "w": 15.385
  },
  "p88": {
   "src": "assets/sprites/p88_eye.webp",
   "x": 38.774,
   "y": 14.726,
   "w": 23.89
  }
 },
 "bg": {
  "linglong": "assets/bg/linglong.jpg",
  "yanxia": "assets/bg/yanxia.jpg",
  "yanxia_rain": "assets/bg/yanxia_rain.jpg",
  "duanya": "assets/bg/duanya.jpg",
  "cangjing": "assets/bg/cangjing.jpg",
  "jingshui": "assets/bg/jingshui.jpg",
  "gate": "assets/bg/gate.jpg",
  "xuannv": "assets/bg/xuannv.jpg",
  "yanxia2": "assets/bg/yanxia2.jpg"
 },
 "bgm": {
  "yun": "assets/bgm/yun.mp3"
 },
 "meta": {
  "p44": {
   "ar": 0.52667,
   "w": 790,
   "h": 1500,
   "eyeY": 0.1205
  },
  "p47": {
   "ar": 0.48467,
   "w": 727,
   "h": 1500,
   "eyeY": 0.124
  },
  "p54": {
   "ar": 0.38533,
   "w": 578,
   "h": 1500,
   "eyeY": 0.1087
  },
  "p61": {
   "ar": 0.608,
   "w": 912,
   "h": 1500,
   "eyeY": 0.1523
  },
  "p88": {
   "ar": 0.736,
   "w": 1104,
   "h": 1500,
   "eyeY": 0.2025
  }
 },
 "video": {}
};
